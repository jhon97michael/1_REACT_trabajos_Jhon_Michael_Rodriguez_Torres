


const Text2 = () => {
    return (
        <div>

        </div>
    ):
}
export default Text2;