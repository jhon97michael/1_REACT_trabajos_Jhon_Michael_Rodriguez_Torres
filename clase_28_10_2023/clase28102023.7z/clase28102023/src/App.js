import logo from './logo.svg';
import './App.css';
import Counter from './componentes/Counter';
import Text from './componentes/Text';

function App() {
  return (
    <div className="App">
      <Counter />
      <Text />
    </div>
  );
}

export default App;
